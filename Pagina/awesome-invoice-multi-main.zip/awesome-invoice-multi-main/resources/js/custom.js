
function showLoadingText(){
	
}
function hideLoadingText(){

}