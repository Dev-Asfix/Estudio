<template>
  <div>
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Application Information</h1>
    <p class="mb-4">
    </p>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
      <!--  <div class="card-header py-3">
              
            </div> -->
      <div class="card-body">
        Aweseome Invoice software solves the problem of traditional way of Billing and managing stock. This application is developed by BatikLeaf. This application is curretly on beta testing mode. You can always report the bugs and problems to developer or company site.
        <h6 class="m-0 mt-2 font-weight-bold text-primary">Licence</h6>
        <p></p>
      </div>
    </div>
  </div>
</template>

<script>
export default {

  data() {
    return {


    }
  },
  created() {
    //this block will execute when component created


  },

  methods: {


    //end of methods block
  }

}
</script>
