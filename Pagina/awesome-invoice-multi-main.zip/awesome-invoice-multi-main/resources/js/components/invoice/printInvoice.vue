<template>
  <div class="content-container">
    <h4>Hello this is print Invoice</h4>
  </div>
</template>