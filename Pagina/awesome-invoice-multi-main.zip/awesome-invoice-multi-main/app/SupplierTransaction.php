<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SupplierTransaction extends Model
{
    //
}
