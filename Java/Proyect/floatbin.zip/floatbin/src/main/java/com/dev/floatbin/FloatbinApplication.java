package com.dev.floatbin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FloatbinApplication {

	public static void main(String[] args) {
		SpringApplication.run(FloatbinApplication.class, args);
	}

}
