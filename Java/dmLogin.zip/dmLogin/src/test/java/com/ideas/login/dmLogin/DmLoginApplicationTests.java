package com.ideas.login.dmLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
