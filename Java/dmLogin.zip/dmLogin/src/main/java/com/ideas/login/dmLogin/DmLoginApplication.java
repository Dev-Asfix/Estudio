package com.ideas.login.dmLogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DmLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(DmLoginApplication.class, args);
	}

}
